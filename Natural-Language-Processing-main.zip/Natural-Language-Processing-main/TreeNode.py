class TreeNode(object):
    def __init__(self, val, embedding):
        self.val = val
        self.embedding = embedding

        self.left = None
        self.right = None
        self.height = 1


