# This code calculates through nodes how close words are to eachother. 
